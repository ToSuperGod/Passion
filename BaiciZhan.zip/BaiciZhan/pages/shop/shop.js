// pages/shop/shop.js

const app=getApp()
let {shop_list}=app.globalData

let stationery=shop_list.filter(function(value,index){
  return /文具/.test(value.variety)
})
let reading=shop_list.filter(function(value,index){
return /读物/.test(value.variety)
})

Page({

  /**
   * 页面的初始数据
   */
  data: {
    nav_list:[
      {
        id:0,
        title:"首页",
        pagename:"shop",
        isActive:true
      },
      {
        id:1,
        title:"全部",
        pagename:"all",
        isActive:false
      },
      {
        id:2,
        title:"文具",
        pagename:"stationery",
        isActive:false
      },
      {
        id:3,
        title:"读物",
        pagename:"reading",
        isActive:false
      }
    ],
    shop_list:shop_list,
    stationery,
    reading
  },
  //修改激活item
  changeItem(e){
    let {id}=e.target;
    let {nav_list}=this.data
    nav_list.forEach(function(v,i){
      if(v.id==id){
        v.isActive=true
      }else{
        v.isActive=false
      }
    })
    this.setData({
      nav_list
    })
  },
  tap(){
    console.log(stationery,2121,reading)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // console.log(shop_list)
    
    console.log(stationery,2121,reading)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})